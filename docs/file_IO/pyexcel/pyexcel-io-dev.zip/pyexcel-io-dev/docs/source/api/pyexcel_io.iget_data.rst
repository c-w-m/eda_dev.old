pyexcel\_io.iget\_data
======================

.. currentmodule:: pyexcel_io

.. autofunction:: iget_data